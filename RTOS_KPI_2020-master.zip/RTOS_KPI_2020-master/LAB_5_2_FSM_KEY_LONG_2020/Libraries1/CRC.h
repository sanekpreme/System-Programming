char calc_CRC(char buffer[],int count);
char check_CRC(char buffer[],int count);
