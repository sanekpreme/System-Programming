#include "stm32f10x.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "misc.h"
#include <stdio.h> 

void delay_from_Brown(uint32_t nTime);
void sys_tick_ini(void);

