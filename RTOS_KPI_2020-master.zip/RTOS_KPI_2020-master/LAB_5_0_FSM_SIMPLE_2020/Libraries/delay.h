void delay_us( unsigned long Val);
void delay_ms( unsigned long Val);
